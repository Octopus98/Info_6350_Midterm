//
//  Constants.swift
//  NEUStockApp
//
//  Created by Octopus John on 2/18/23.
//

import Foundation

let apiKey = "0ebc5b8e240fed625a03bbc695cb1d0d"
let baseURL = "https://financialmodelingprep.com/api/v3/profile/"
