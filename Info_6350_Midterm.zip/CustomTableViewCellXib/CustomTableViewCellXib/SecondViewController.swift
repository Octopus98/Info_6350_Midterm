//
//  SecondViewController.swift
//  CustomTableViewCellXib
//
//  Created by Octopus John on 3/18/23.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var textDes: UITextView!
    
    var desContent = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(desContent)
        textDes.text = desContent
        // Do any additional setup after loading the view.
    }
    

}
