//
//  ViewController.swift
//  CustomTableViewCellXib
//
//  Created by Drillmaps on 13/02/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    let imageName = ["wonder0", "wonder1", "wonder2", "wonder3", "wonder4", "wonder5", "wonder6"]
    let desTextArr = ["Great Wall", "Chichén Itzá", "Petra", "Machu Picchu", "Christ the Redeemer", "Colosseum", "Taj Mahal"]
    var desContent = ""

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        desContent = desTextArr[indexPath.row]
        performSegue(withIdentifier: "segue", sender: self)
        print(desContent)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return imageName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("TableViewCell", owner: self)?.first as! TableViewCell
        let picName = ["Great Wall", "Chichén Itzá", "Petra", "Machu Picchu", "Christ the Redeemer", "Colosseum", "Taj Mahal"]
        cell.imageContainer.image = UIImage(named: "wonder\(indexPath.row)")
        cell.lblImage.text = picName[indexPath.row]
        return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("sss")
        if segue.identifier == "segue"{
            let secondVC = segue.destination as! SecondViewController
            secondVC.desContent = self.desContent
            print(secondVC.desContent)
        }
    }

}

